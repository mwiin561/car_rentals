from truck import Truck
from garage import Garage

def get_example():
    truck = Truck("black", False)
    garage = Garage()
    garage.set_vehicle(truck)
    print(garage)

if __name__ == "__main__":
    get_example()