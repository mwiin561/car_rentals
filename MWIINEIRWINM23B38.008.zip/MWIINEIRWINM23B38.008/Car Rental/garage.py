class Garage:
    def __init__(self):
        self.parked_vehicle = None

    def set_vehicle(self, parked):
        self.parked_vehicle = parked

    def __str__(self):
        return "Description of the parked vehicle:\n" + str(self.parked_vehicle)