class Customer:
    def __init__(self, name, address):
        self.name = name
        self.address = address


    def get_name(self):
        return self.name

    def get_address(self):
        return self.address

    
    def set_name(self, name):
        self.name = name

    def set_address(self, address):
        self.address = address