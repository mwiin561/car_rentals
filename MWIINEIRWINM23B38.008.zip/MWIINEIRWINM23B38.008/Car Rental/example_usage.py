## testing just in case 
##importing stuff from the other created classes
from vehicle import Vehicle
from car import Car
from truck import Truck
from garage import Garage
from customer import Customer

#then doing the rest......
def main():

    john_doe = Customer("John Doe", "123 Main Street")
    red_car = Car("red", has_winter_tires=True)
    rental_garage = Garage()
    rental_garage.set_vehicle(red_car)

    #printy part
    print("Customer Information:")
    print(f"Name: {john_doe.get_name()}")
    print(f"Address: {john_doe.get_address()}")

    print("\nRented Vehicle Information:")
    print(rental_garage)

if __name__ == "__main__":
    main()
#hopefully it works.
